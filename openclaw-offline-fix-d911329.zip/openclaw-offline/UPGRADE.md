# OpenClaw 离线升级方案

**适用范围**：`openclaw-offline` 这个包在气隙 Win10 x64 目标机上的**版本升级**（本次：`2026.9.5 → 2026.10.3`）。
**版本无关**：脚本不钉死 openclaw 版本——升级目标、版本号、schema 声明全部从 **bundle 与 `bundle-manifest.json`** 读取，预检脚本还会断言这些契约在 Make/Install/Upgrade 三处一致。换版本只需**重新打一个包**（见 §3.2）。
**本文性质**：设计文档。结论优先依据 openclaw 官方文档；官方未定义的部分单独标注为"工程补充"，未经实机验证的标注为"待验证"。
**术语**：气隙机（air-gapped host）＝与互联网无任何链路、数据只能靠 U 盘搬运的机器；本项目目标机**内网可达**，所以"气隙"只否决"安装时回源"的设计，不否决局域网内访问（见 [README §2.3](../README.md#23-网络)）。

标注约定：

| 标记 | 含义 |
| --- | --- |
| `[文档]` | 出自 openclaw@2026.9.9 包内 `package/docs/**` 或 `package/CHANGELOG.md`，附 `文件:行` |
| `[实测]` | 本仓库在 macOS 上用真实 `openclaw@2026.9.5` / `2026.9.9` 包做的等价验证 |
| `[工程补充]` | 官方文档没有定义、由本仓库补上的动作 |
| `[待验证]` | 必须在真机上确认后才能当结论用的点 |

---

## 1. 结论摘要

1. **主路径用官方 updater，升级目标用本地 tarball**：`openclaw update --tag <bundle>\openclaw-<ver>.tgz`。官方明确把"显式 artifact（tarball 路径）"与注册表目标视为同一条流程 `[文档]` `docs/cli/update.md:202`，且非注册表 spec 会跳过 npm 版本查询（`[实测]` dry-run 输出 *"Non-registry package specs skip npm version lookup"`）。
2. **官方没有离线模式**：没有 `--offline` 参数、没有气隙流程、没有本地 registry 指南 `[文档]`（子代理逐条检索未找到）。tarball 也不自带全部依赖——9.9 的 tarball 只含 3 个包（`@openclaw/proxyline`、`chrome-devtools-mcp`、`undici`），而 `package.json` 声明 66 个依赖 `[实测]`。**所以离线可行性 = 随包带一份为新版本预热的 npm cache，并让 npm 走缓存。**
3. **前提是安装"有主"**：updater 要求能从 npm 配置的 prefix + 已安装启动器推断出 owner `[文档]` `docs/cli/update.md:20-24`；否则记录为 **skipped**、退出 0、不升级 `[文档]` `docs/cli/update.md:33-37`。我们现在的 `C:\OpenClaw\app` 是 robocopy 过来的全局 prefix，默认情况下 npm 的全局 prefix 指向别处 —— `[实测]` 在 macOS 上撞到 `global-install-foreign-destination`；用 `NPM_CONFIG_PREFIX` 对齐到该树后 dry-run 立即通过。
4. **本次升级的一个硬性顺序**：目标机是 2026.9.5，而"9.5 的 Gateway 没有安装替换监听器"，第一跳必须**先停 Gateway 并等它退出**，再 update，再启动 `[文档]` `docs/cli/update/how-updates-run.md:848-852`。
5. **升级前必须有恢复点，而且这次是唯一回滚路径**：`update` 自带的只是"升级前配置副本"，不是全量恢复点 `[文档]` `docs/install/updating/rollback-and-recovery.md:276-277`；DB/config 迁移是单向的 `[文档]` `docs/reference/database-schemas/integrity-and-recovery.md:516`。
6. **版本升级不需要改脚本**：唯一被钉死的只有“跨版本稳定”的契约（包名、目标平台、默认端口、Node 窗口、manifest schema），它们由预检脚本的跨文件断言守着；版本号、tarball、schemaVersions、原生包清单都是**读出来的**。2026.10.3 的逐条核对与构建实测见 §3.2。
7. **本次升级确认跨数据库 schema 迁移（已实证）**：9.5 声明 `state 17 / agent 21`，9.9 声明 `state 19 / agent 24`；9.5 建的 state 库 `user_version=17`，被 9.9 打开后变 `19`，随后 9.5 **拒绝打开**该库。**所以升级后"换回旧包"救不回来**，官方自动回滚也不适用，回滚 = 恢复升级前的 `backup create` 归档。详见 §2.8。
7. **顺手要关掉自动出网检查**：`update.checkOnStart` 默认 `true`，Gateway 每次启动 + 每 24h 请求 `https://telemetry.openclaw.ai/api/latest-version` `[文档]` `docs/gateway/config-runtime.md:140`；气隙机上应设 `false`（或 `OPENCLAW_NO_AUTO_UPDATE=1`）。
8. **本次不需动 Node**：9.5 与 9.9 的 engines 完全相同 `>=24.16.0 <25 || >=26.1.0`，下限是 2026.9.3 引入的 `[文档]` `docs/install/node-compatibility.md:21,89`；目标机 nvm 的 26.7.0 继续有效。

---

## 2. 官方升级机制（事实与出处）

### 2.1 命令面

```
openclaw update [--tag <dist-tag|version|spec>] [--channel stable|extended-stable|beta|dev]
                [--dry-run] [--no-restart] [--yes] [--json] [--timeout <s>]
                [--admission auto|installed] [--accept-capabilities] [--reapply-local-overrides]
openclaw update status [--json] [--timeout <s>]
openclaw update repair [--channel <c>] [--yes] [--json] [--no-restart]
openclaw update cleanup [--dry-run] [--yes] [--json]
openclaw update wizard [--timeout <s>]
openclaw --update          # 等价于 openclaw update
```

- 命令面与参数表：`[文档]` `docs/cli/update.md:46-62`、`379-390`；`--update` 等价别名：`docs/cli/update.md:64-65`。
- 阶段：requested → staging → validating → activating → restarting → verifying → finished；**只有 activating 会停托管服务** `[文档]` `docs/cli/update.md:398-401`、`docs/cli/update/how-updates-run.md:430`。
- npm 安装的落地方式：先 stage 到临时 prefix，再把干净的包树 swap 进真实全局 prefix `[文档]` `docs/cli/update/how-updates-run.md:1088-1096`。
- **没有** `update history`、**没有** `update rollback` 子命令；历史查 `update status --json` 的 `activeRun`/`lastRun` `[文档]` `docs/cli/update/status-and-history.md:123-124`。

### 2.2 本地 artifact 是官方认可的升级目标

| 事实 | 出处 |
| --- | --- |
| "Registry targets and explicit artifacts such as `--tag ./openclaw.tgz` use the same flow." | `[文档]` `docs/cli/update.md:202` |
| 显式 artifact（tarball 路径/URL）即使版本相同也会被校验并安装 | `[文档]` `docs/install/updating.md:314-316`、`docs/cli/update/how-updates-run.md:96` |
| npm 12 下本地 `.tgz` 的**文件名与父目录都不能含逗号**；相对路径仍支持 | `[文档]` `docs/install/installer.md:23`、`docs/install/updating/update-methods.md:367-368` |
| 包 spec 形态示例：`--tag openclaw@2026.4.1-beta.1` | `[文档]` `docs/install/development-channels.md:82-96` |
| 官方**未**定义 `file:` 形式、未定义离线模式 | 子代理检索结论（包内文档无对应条目） |

### 2.3 "有主"是硬前提

- owner 由 **npm 配置的 prefix + 已安装启动器**推断；自定义 prefix（如 `~/.npm-global`）受支持 `[文档]` `docs/cli/update.md:20-24`。
- prefix 配置不一致时的官方兜底写法：`NPM_CONFIG_PREFIX="$(npm prefix -g)" openclaw update` `[文档]` `docs/cli/update.md:29-31`。
- **无主 = 不升级**：记录 skipped、退出 0、Gateway 继续跑，提示"用原始方法重装" `[文档]` `docs/cli/update.md:33-37`。
- `[实测]` 在 macOS 上把 CLI 装进 `/tmp/oc95`、而 npm 全局 prefix 仍是 `~/.local` 时，实际升级被拒：
  `global-install-foreign-destination — Selected npm destination … is occupied by another OpenClaw installation… No installation was attempted.`
  把 `NPM_CONFIG_PREFIX` 对齐到该树后，同一命令 `--dry-run` 输出计划：`Tag/spec: …`、`Run global package manager update with spec …`。

### 2.4 失败是非破坏性的

- "a refusal or pre-mutation failure … leaves the installed package and serving Gateway in place." `[文档]` `docs/cli/update.md:204-205`；同类表述另见 `how-updates-run.md:418`、`update-methods.md:17`、`install/updating.md:272-273`。
- Windows 文件占用：对 `EPERM`/`EBUSY`/`EACCES` 重试 16 次、最多约 57.75s；仍失败则报错并**保留**原安装 `[文档]` `docs/cli/update.md:190-196`。

### 2.5 2026.9.5 专属约束（正对本次升级）

| 约束 | 出处 |
| --- | --- |
| 9.5 的 Gateway 没有 installation-replacement watcher；第一跳必须由前台进程所有者停掉 Gateway、等它退出，再 update，再启动 | `[文档]` `docs/cli/update/how-updates-run.md:848-852` |
| Windows 上计划任务自启动会挂起到候选 finalizer 激活为止；旧驱动停在 recovery pending 时用 `openclaw update repair` | `[文档]` `docs/cli/update/how-updates-run.md:495-501` |
| 9.5 resident 保留旧启动预算，第一次停走"短/未知预算"路径 | `[文档]` `docs/cli/update/how-updates-run.md:68-70` |
| 第一跳受旧驱动 settlement 检查限制 | `[文档]` `docs/install/updating/rollback-and-recovery.md:247-248` |

### 2.6 服务（用户级计划任务）

- `openclaw daemon …` 与 `openclaw gateway …` 是同一套服务控制命令 `[文档]` `docs/cli/daemon.md:11`。
- **升级后的官方动作**：`openclaw gateway install --force` 重新生成 launcher/任务 `[文档]` `docs/platforms/windows.md:170-171`、`docs/gateway/doctor/gateway-and-services.md:210`。
- 但 Windows 上 updater **不会**重绑服务定义（`--no-restart` 也不会）`[文档]` `docs/install/node.md:82-88` → 必须显式执行上一条。
- 重启用 `gateway restart`，不要 stop+start 串联 `[文档]` `docs/cli/gateway/service.md:220`；重启成功需通过监听检查（最长 3 分钟），否则 `gateway restart --force` `[文档]` `docs/cli/gateway/restart-and-supervision.md:95-103`。
- Windows 任务名 `OpenClaw Gateway` / `OpenClaw Gateway (<profile>)`；任务被拒时回退到"用户启动文件夹"登录项（仍然无需管理员）`[文档]` `docs/platforms/windows.md:156-159`、`docs/gateway/index.md:299-300`。
- 停止：`schtasks /end /tn "OpenClaw Gateway"` 或 `Stop-ScheduledTask` `[文档]` `docs/platforms/windows.md:168-170`。

### 2.7 配置与状态迁移归 Doctor，不归安装

- "Plugin-registry and operator-state migration belong to Doctor, not package installation." `[文档]` `docs/install/updating/update-methods.md:420-422`。
- 启动**不**改写旧配置键，只打印 `openclaw doctor --fix` 提示 `[文档]` `docs/gateway/doctor/config-migrations.md:296`；普通 doctor（含 `--non-interactive`）可自动规范化旧的单文件配置 `[文档]` `:292`。
- 改写前保留 `openclaw.json.bak` / `.bak.1`…`.bak.4` 五槽备份环 `[文档]` `:296`。
- **迁移窗口约 2 个月**；更老的键已无迁移路径、直接校验失败；官方对"更老安装"的建议是**先升到 2026.9.5 并跑其 Doctor 迁移，再装最新版** `[文档]` `docs/gateway/doctor/config-migrations.md:316-341`。→ 我们正处在 9.5，这一步天然满足。
- 升级后专用检查：`openclaw doctor --post-upgrade`（可配 `--fix`）`[文档]` `docs/cli/doctor/running.md:226-243`。

### 2.8 数据库与 schema

- 前向迁移单向；启动遇到更新 schema 会**退出码 78**；`openclaw update` 也会拒绝"声明 schema 支持比磁盘数据库更旧"的目标 `[文档]` `docs/reference/database-schemas/versioning.md:17,19`。
- 迁移不可逆，且"降级包不会回退已迁移的状态" `[文档]` `docs/reference/database-schemas/integrity-and-recovery.md:516`。
- 升级/回滚前的推荐动作：由 supervisor 生成**无 sidecar 的 WAL 一致快照**，再用目标版本的 `openclaw database preflight <snapshot> --json` 判定（`exact` / `startup-repairable` / `migration-required` / `incompatible` / `indeterminate`）`[文档]` `docs/cli/gateway/restart-and-supervision.md:178`、`docs/reference/database-schemas/storage-changes.md:2016-2051`。
- 不要只拷主 `.sqlite`（WAL）`[文档]` `docs/install/updating/rollback-and-recovery.md:78-81`；不要手改 `user_version` / `schema_meta.schema_version` `[文档]` `docs/reference/database-schemas/integrity-and-recovery.md:580-582`。

**schema 链逐版递增**：9.5 = `state 17 / agent 21` → 9.9 = `state 19 / agent 24` → **2026.10.3 = `state 20 / agent 24`** `[实测]`（后者读自 10.3 的 `package.json`）。目标机的 17 会在一跳内前向迁到目标版本，回滚仍只能靠升级前备份。

**本次升级已实证跨 schema 迁移** `[实测]`：

| 观测 | 结果 |
| --- | --- |
| 9.5 包内 `openclaw.schemaVersions` | `{ state: 17, agent: 21 }` |
| 9.9 包内 `openclaw.schemaVersions` | `{ state: 19, agent: 24 }` |
| 9.5 建库后 state 库 `PRAGMA user_version` | `17` |
| 用 9.9 打开同一状态目录后 | `19`（迁移已发生） |
| 再用 9.5 打开 | 被拒：`uses newer schema version 19; this build supports 17`，并提示 `To use an older build, restore your pre-update backup created with openclaw backup create.`（CLI 退出码 1；doctor JSON 退出码 2） |

结论：**升级后旧包无法启动**，`openclaw update --tag 2026.9.5` 这类降级同样会被 updater 拒绝（目标声明的 schema 支持比磁盘库旧 `[文档]` `docs/reference/database-schemas/versioning.md:17`）。回滚 = 恢复升级前备份，且该归档必须放在状态目录之外。

### 2.9 备份与回滚

- 官方升级前配方 `[文档]` `docs/install/updating/rollback-and-recovery.md:280-283`：
  ```
  openclaw backup create --output <dir> --verify
  ```
- `backup restore` **从不就地**、无 `--force`，目标是空目录/不存在；激活要停 Gateway、指向恢复出的状态目录、先跑 doctor `[文档]` `docs/cli/backup.md:71-92`、`docs/install/backups.md:351-423`。
- 自动回滚仅在**无 schema 迁移**时可用（恢复包、命令 shim、服务定义、激活前配置字节），命令仍返回非 0 `[文档]` `docs/install/updating/rollback-and-recovery.md:150-195`。
- 手工降级：`openclaw update --tag <known-good-version>`（通道为 extended-stable 时需加 `--channel stable`）`[文档]` `:45-58`。
- 已跨 schema 迁移时：唯一受支持的恢复是"恢复升级前的已验证备份 + 匹配版本" `[文档]` `:16-19`。
- `openclaw update cleanup` 会永久放弃回滚原件，默认确认 No，自动化需 `--yes` `[文档]` `docs/install/updating.md:739-762`。

### 2.10 通道与自动更新

- `stable`=npm `latest`（现 9.9）；`extended-stable`=月度支持线（现 2026.8.35，永不自动）；`beta`；`dev`=git main `[文档]` `docs/install/development-channels.md:13-23`。
- `--channel` 成功后持久化到 `update.channel`；`--tag` 是一次性、不改持久通道 `[文档]` `:38-39`、`82-96`；extended-stable 拒绝 `--tag` `[文档]` `docs/install/updating.md:381`；降级需确认（`--yes` 跳过）`[文档]` `docs/install/development-channels.md:113-114`。
- 配置块 `[文档]` `docs/gateway/config-runtime.md:125-141`：
  ```json5
  { update: { channel: "stable", checkOnStart: true, auto: { enabled: false } } }
  ```
- `checkOnStart: false` 或 `OPENCLAW_NO_AUTO_UPDATE=1` 可关闭全部自动更新请求与统计 `[文档]` `:140`；`auto.enabled` 默认 false `[文档]` `:141`。
- 故障恢复期建议设 `OPENCLAW_NO_AUTO_UPDATE=1`，避免自动更新器立刻把新版装回来 `[文档]` `docs/install/updating/rollback-and-recovery.md:91-93`。
- `[实测]` 本机已跑通两个将写进脚本的动作：`openclaw config set update.checkOnStart false` 生效（`config get update` → `{"checkOnStart": false}`，`config validate` 通过）；`openclaw backup create --output <已存在目录> --verify` 输出 `Archive verification: passed`，归档为 `<目录>\<时间戳>-openclaw-backup.tar.gz`。

### 2.11 Node

- 9.5 与 9.9 的 engines 相同；下限由 2026.9.3 引入 `[文档]` `docs/install/node-compatibility.md:21,89`。
- 门禁是能力检测而非只比版本：会用内存库探 `node:sqlite` 绑定，版本合规但探针失败也会被拒 `[文档]` `:25`。
- update 时若当前 Node 跑不了目标版本，updater 会挑一个已装的兼容 Node，或**悄悄安装私有 Node 运行时** `[文档]` `docs/install/node.md:68-73` → 气隙机上必须避免走到这一步（保持 PATH 上的 Node 合规），失败码 `node-runtime-preflight` `[文档]` `docs/install/updating.md:266-269`。

---

## 3. 现状与官方路径的差距

| # | 差距 | 证据 |
| --- | --- | --- |
| 1 | `C:\OpenClaw\app` 是 robocopy 来的全局 prefix，npm 的全局 prefix 在别处 → updater 可能判为无主/异地 | `[实测]` `global-install-foreign-destination`；`[文档]` `docs/cli/update.md:20-24,33-37` |
| 2 | 无随包 npm cache → 本地 tarball 装不齐 ~63 个传递依赖 | `[实测]` tarball 只自带 3 个包 |
| 3 | 无升级入口；现有 `install.cmd` 走 `-Force` 整树重装，会重跑 `onboard`（改写 provider 配置风险） | 本仓库 [Install-OpenClawOffline.ps1](Install-OpenClawOffline.ps1) |
| 4 | 未关 `update.checkOnStart` → 气隙机上每次启动都有失败的出网请求 | `[文档]` `docs/gateway/config-runtime.md:140` |
| 5 | 升级前无恢复点、无停服骨架、未处理 9.5 第一跳与 Windows 服务重绑 | `[文档]` §2.5、§2.6 |

### 3.1 构建侧实测记录（编号链）

构建侧：macOS + Node 26.7.0 + npm 11.19.0，使用真实 `openclaw@2026.9.5` / `2026.9.9` 包。

1. **离线升级可行性**：暖缓存 + `--offline` 下把 9.5 树原地升到 9.9 成功
   （`added 20 packages, removed 6 packages, and changed 323 packages`），版本变为 `OpenClaw 2026.9.9 (bcfc888)`，
   文件数 `41,406` 与全新 9.9 树一致 → **不残留旧版文件**。
2. **体积**：app 树 574 MB（9.5，37,226 文件）/ 730 MB（9.9，41,406 文件）；tarball ~114 MB。
   （README 早期写的 "~390MB" 是包的 `unpackedSize`，不是完整树。）
3. **schema 迁移**：9.5 声明 `state 17 / agent 21`，9.9 声明 `state 19 / agent 24`；9.5 建库
   `user_version=17` → 9.9 打开后 `19` → 9.5 再打开被拒
   （`uses newer schema version 19; this build supports 17`，CLI 退出码 1、doctor JSON 退出码 2）。
4. **官方 updater 接受本地 artifact**：`--tag file:<tgz>` 的 dry-run 打印
   *"Non-registry package specs skip npm version lookup"*，即目标选择不需要联网。
5. **owner 判定**：npm 全局 prefix 与该树不一致时被拒（`global-install-foreign-destination`，
   *No installation was attempted*）；用 `NPM_CONFIG_PREFIX` 对齐到该树后同一命令 dry-run 通过。
6. **缓存键陷阱**：把 registry 指向死地址会让 npm 缓存键失配（`ENOTCACHED`）——离线验证必须用 `--offline`，
   不要改 registry。失败是**非破坏**的：版本与文件数保持不变。
7. **平台包扫描**：真实 macOS 树上抓出 6–7 个非 win32 包（`@esbuild/darwin-arm64`、
   `@koromix/koffi-darwin-arm64`、`@lydell/node-pty-darwin-arm64`、`@openclaw/fs-safe-darwin-arm64`、
   `@trycua/cua-driver-darwin-arm64`、`@ubjs/node-darwin-arm64`、`sqlite-vec-darwin-arm64`）；
   合成树上 `*-win32-x64` / `*-windows-x64` 记入 `nativePackages`，而**嵌套布局**里的 darwin 包被判为 foreign。
8. **配置与备份动作**：`config set update.checkOnStart false` 生效（`config get update` →
   `{"checkOnStart": false}`，`config validate` 通过）；`backup create --output <已存在目录> --verify`
   输出 `Archive verification: passed`，归档名为 `<目录>\<时间戳>-openclaw-backup.tar.gz`。
9. **macOS 无法复现的部分**：`openclaw update` 的 handoff 身份校验依赖进程启动时间，而本沙箱禁用 `ps`
   （darwin 无 argv 回退）→ 官方 update 的端到端只能在 Windows 上验证（见 §8）。

---

### 3.2 2026.10.3 核对结果（新版发布后重跑，脚本零改动）

发布线变动：`latest` 由 `2026.9.9` → **`2026.10.3`**（`beta` = `2026.10.5-beta.3`，`extended-stable` 仍为 `2026.8.35`）。
用 `npm view` 元数据 + 真实 tarball（102.9 MB）逐条核对脚本依赖的契约：

| 契约 | 2026.9.9 | 2026.10.3 | 影响 |
| --- | --- | --- | --- |
| `engines.node` | `>=24.16.0 <25 \|\| >=26.1.0` | **相同** | 脚本里的 Node 窗口常量不用改 |
| `bin` | `openclaw` → `openclaw.mjs` | **相同** | 启动器探测逻辑不变 |
| `openclaw.updateAdmissionProtocol` | 1 | **1** | first-hop 判定协议未变 |
| `openclaw.schemaVersions` | state 19 / agent 24 | **state 20 / agent 24** | 9.5 的 state 17 一跳迁到 20；回滚仍只能靠备份（§2.8） |
| `docs/` 随包发布 | 有 | **有**（tar 内 1303 项，构建侧抽出 1296 篇 markdown） | npmcache 模式的文档抽取仍可用 |
| 脚本用到的 27 个 CLI 参数/命令 | — | **全部存在** | 安装/升级流程无需改；`global-install-foreign-destination`、`update.checkOnStart`、`newer schema version`、`update repair` 均在 |
| CHANGELOG | — | **无破坏性变更、无配置迁移要求** | 另有数条正好有利于本部署：防止升级中误判 owner 丢失、Windows 计划任务账号与短路径修复、npm 全局升级不再残留无关包 |

**构建侧实测（本次，macOS）**：`Make-OpenClawOfflineBundle.ps1 -Mode npmcache -OpenClawVersion 2026.10.3` **零改动跑通**（exit 0）。
产物 **439 MB**：`npm-cache` 320 MB + `openclaw-2026.10.3.tgz` 98 MB + `docs` 20 MB / 1296 页；manifest 记录
`schemaVersions {state:20, agent:24}`、`nativePackages` 7 个（`@esbuild/win32-x64`、`@koromix/koffi-win32-x64`、
`@lydell/node-pty-win32-x64`、`@openclaw/fs-safe-win32-x64-msvc`、`@trycua/cua-driver-win32-x64-msvc`、
`@ubjs/node-win32-x64-msvc`、`sqlite-vec-windows-x64`），tarball SHA256 与 manifest 自校验一致。

**阶梯升级仍按官方要求**：新版文档依然要求“2026 年 7 月之前的安装先经 `2026.9.5`”（`docs/install/updating.md:30`）；
目标机现装就是 9.5 → **直接升 10.3 就是文档路径**，不必先经 9.9。

> 本次实跑同时修掉了 npmcache 路径上 4 个隐藏缺陷（见 §6.1 前四行）；`-Mode app` 仍必须在 Windows x64 上构建。

---

## 4. 已定决策

| 项 | 决定 |
| --- | --- |
| 通道 | `stable`，本次升到 **2026.10.3** |
| 升级包形态 | **tarball + 为新版本预热的 npm cache**，另附完整整树作为救援/重装（**不能用于回滚**：跨 schema 后旧包起不来，见 §2.8） |
| 目标机 npm | **允许执行**，但仅限升级脚本内部，且必须走随包 cache + 离线变量 |
| 主路径 | 官方 `openclaw update --tag <本地 tarball 路径>` |
| 升级前 | 必须 `backup create --verify`（**本次是唯一回滚路径**，归档要放在状态目录之外）；必须停 Gateway 并等退出（9.5 第一跳） |
| dry-run 阶段 | 必须验证 owner 判定与依赖走缓存；`database preflight` 改为可选留证（schema 迁移已确认，见 §2.8） |

---

## 5. 升级流程（逐步）

来源标注：`[文档]` 为官方要求；`[工程补充]` 为官方未定义、由本仓库补上；`[必验]` 为本方案落地前必须在真机确认的判定点。

```
# 0) 前置（由新的安装流程保证，只需一次）
#    首次安装即写入 update.checkOnStart=false            [文档] config-runtime.md:140
#    并让安装树"有主"：NPM_CONFIG_PREFIX=<InstallRoot>\app [文档] cli/update.md:20-31

# 1) 恢复点（⚠ --output 指向已存在目录才会在里面生成带时间戳的 .tar.gz；
#    指向不存在的路径会被当成归档文件本身 —— 所以必须先建目录，官方配方亦如此）[实测]
New-Item -ItemType Directory -Force -Path C:\Backups\openclaw | Out-Null
openclaw backup create --output C:\Backups\openclaw --verify          [文档] rollback-and-recovery.md:280-283

# 2) 停 Gateway 并等它完全退出（9.5 第一跳的硬性要求）
openclaw gateway stop                          # 必要时 --force
#   或 schtasks /end /tn "OpenClaw Gateway"                          [文档] platforms/windows.md:168-170
#   注意：9.5 第一次停走"短/未知预算"路径，退出可能不优雅  [文档] how-updates-run.md:68-70

# 3) 预演 + 判定
$env:NPM_CONFIG_PREFIX = '<InstallRoot>\app'                          [文档] cli/update.md:29-31
openclaw update --dry-run --yes --no-restart --tag D:\bundle\openclaw-2026.10.3.tgz
#   可选留证（已确认本次跨 schema 迁移，故不再是判定项）:
openclaw database preflight <WAL一致快照>.sqlite --json               [文档] restart-and-supervision.md:178

#    离线依赖解析所需的两个变量（官方未定义，属工程补充）        [工程补充]
$env:npm_config_cache   = 'D:\bundle\npm-cache'
$env:npm_config_offline = 'true'

# 4) 正式升级（不加 --no-restart，让 updater 处理重启阶段）
openclaw update --yes --tag D:\bundle\openclaw-2026.10.3.tgz

# 5) Windows 收尾
openclaw gateway install --force               # 重新生成计划任务 launcher  [文档] platforms/windows.md:170-171
openclaw gateway restart                       # 不要 stop+start 串联        [文档] gateway/service.md:220
openclaw doctor --post-upgrade                 # 升级后专用检查              [文档] cli/doctor/running.md:226-243
openclaw health
openclaw gateway status --deep --json
openclaw doctor --lint --json

# 6) 异常处置
openclaw update repair --yes --json            # 停在 recovery pending 时    [文档] how-updates-run.md:495-501
openclaw backup restore <archive> --target <空目录>   # 回滚：本次唯一路径（跨 schema 迁移，见 §2.8）
```

`--dry-run` 阶段的三条硬性检查（失败即停止升级）：**owner 判定通过**、**依赖能走缓存解析**（无出网需求）、**升级前备份已 `--verify` 通过**（本次是唯一回滚路径，见 §2.8）。
`database preflight` 从"判定项"降级为"留证项"：schema 迁移已确认，做的价值是留存升级前后 `user_version` 的证据（17 → 19）。
降级命令 `openclaw update --tag 2026.9.5` **在本次升级后不可用**（updater 会因目标声明 schema 支持比磁盘库旧而拒绝）——回滚一律走 `backup restore`。

**路径约束**：tarball 文件名与父目录**不能含逗号**（npm 12）`[文档]` `docs/install/installer.md:23`。另：`--tag` 用**路径**写法（官方示例 `./openclaw.tgz`），不要用 `file:` URL。

**`-DryRun` 是独立路径，零副作用**（脚本已实现）：只做 bundle/artifact 校验 → 版本与 schema 比对 →
调用官方 `update --dry-run` 打印计划，**不写备份、不停 Gateway、不改任何文件**。所以生产机上"先预演"是安全的，
真流程（备份 → 停服 → 闸门 → 应用）只在去掉 `-DryRun` 时发生。

---

## 6. 产物与脚本改动清单

### 6.1 Make 侧（已实现）

| 改动 | 说明 |
| --- | --- |
| 新增 `npm pack openclaw@<ver>` | 产出 `openclaw-<ver>.tgz`，记录 SHA256 进 manifest（`packagedTarball` / `tarballSha256`） |
| 新增"预热 cache" | 构建时以同一 `--cache` 目录安装目标版本，天然含全部传递依赖；升级包携带该 cache |
| 保留整树产物 | 作为救援/重装通道（**不含回滚**：跨 schema 后旧包无法启动，见 §2.8） |
| manifest `schemaVersion` 升为 4 | 常量 `$BundleSchemaVersion`；新旧字段见下 |
| manifest 新增字段 | `mode`、`targetPlatform`、`schemaVersions`、`installScriptPackages`、`nativePackages`、`packagedTarball`/`tarballSha256` |
| **新增 `-Mode npmcache`** | 跨平台（含本 macOS 检出）只产出「预热 cache + tarball」：`npm --os=win32 --cpu=x64 --force --ignore-scripts` 预热，依赖脚本留给目标机；**不再无条件创建 `app\`**（否则安装侧的 mode 推断会误判） |
| 跨平台 copy 派发 | `Invoke-CopyTree`：有 robocopy 用它（保持 >=8 失败的语义），否则 `Copy-Item` |
| 平台包扫描 | 递归扫 `node_modules`（含 npm 嵌套布局），非 win32/windows-x64 的平台包**直接构建失败**，并记录 `nativePackages` |
| **修：Unix 主机残留快照** | `Get-ResidueSnapshot` 直接读 `$env:USERPROFILE`/`$env:APPDATA`（Unix 上是 `$null`，`Join-Path` 是终止性绑定错误）→ 一次性解析 `$residueHome`/`$residueAppData`，预检加了负向断言 |
| **修：npm 全局布局** | `npm -g --prefix` 在 Unix 上是 `<prefix>/lib/node_modules`，平台扫描却按 Windows 布局找 → 误报“0 个原生包”。新增 `Get-NpmGlobalModulesRoot` 探测两种布局 |
| **修：空树字节统计** | 空管线的 `Measure-Object -Property Length -Sum` 返回 `$null`，StrictMode 下 `.Sum` 终止报错（npmcache 模式没有 app 树）→ 新增 `Get-TotalBytes` |
| **修：manifest 元数据时序** | npmcache 模式先删 `_cachewarm`、后写 manifest，`schemaVersions` 落成 `null` → 改为删除前读取，并校验请求版本与落盘版本一致 |
| bundle 自包含 | 把 `install.cmd`/`Install-*.ps1`/`upgrade.cmd`/`Upgrade-*.ps1`/`UPGRADE*.md` 拷进包根，双击即可零参数安装 |
| 自带能力边界文档 | `docs\OFFLINE-CAPABILITIES.md` 随包交付；包内文档按模式取自 app 树或 tarball |
| README.txt | 增"升级"段：tarball 路径、cache 路径、回滚只靠备份 |

### 6.2 `Upgrade-OpenClawOffline.ps1`（已实现）

- 参数：`-BundleDir`、`-InstallRoot`（默认 `C:\OpenClaw`）、`-BackupDir`（默认 `C:\Backups\openclaw`）、`-GatewayPort`、`-SkipBackup`、`-DryRun`（只做预演）、`-RescueTree`（整树替换兜底）、`-Force`。
- 流程即 §5：校验 bundle 与 artifact 哈希 → 版本与 schema 对比 → 备份（`backup create --output <目录> --verify`，并校验归档确实生成）→ 停 Gateway 并等待无 node 进程 → dry-run 闸门 → 正式 `update --tag <tgz>` → `gateway install --force` → `gateway restart` → `doctor --post-upgrade` 等验证 → 打印回滚命令。
- 失败时用官方信号给处置建议：`global-install-foreign-destination`/无 owner、`ENOTCACHED`、`node-runtime-preflight`、`newer schema version`、`EPERM/EBUSY/EACCES`。
- 预演失败也会**把 Gateway 起回来**再退出，不让机器停在那（真实流程里已停服才需要这步）。
- `-DryRun` **零副作用**：不备份、不停服、不落地——它走的是独立分支，流程见 §5 末。
- 契约变量（`$BundleSchemaVersion`/`$OpenClawPackage`/`$NodeFloor`/`$TargetPlatform`）与 Make/Install 保持一致，并由预检脚本断言。
- `upgrade.cmd` 提供双击入口，破坏性操作前要求输入 `YES` 确认。
- PowerShell 5.1 约束沿用现有脚本：不加 `Join-Path` 第三参、不做出网假设、`Invoke-Native` 包裹原生命令、纯 ASCII 输出。

### 6.3 安装侧（已实现）

| 改动 | 状态 |
| --- | --- |
| 首次安装写入 `update.checkOnStart=false` | 已实现：安装脚本在配置校验后执行；失败仅告警，可用 `OPENCLAW_NO_AUTO_UPDATE=1` 兜底 |
| 让安装树"有主" | 已实现于升级脚本：调用 updater 前注入 `NPM_CONFIG_PREFIX=<InstallRoot>\app`，不改用户 npm 配置 |
| 标注救援模式 | 已实现：`-Force` 的报错信息改为指路 `Upgrade-OpenClawOffline.ps1`，并注明 `-Force` 是救援重装 |
| 应用树完整性校验 | 已实现：复制后比对 manifest 的 `appFileCount`/`appBytes`，不符即中止（旧 manifest 缺字段时跳过） |
| provider 模板补 `models[].name` | 已实现：零参数安装路径最后那一步 `config patch` 现在能通过 schema 校验 |

### 6.4 交付前预检（已实现）

`Test-OpenClawOfflineScripts.ps1`：解析全部 `.ps1`、校验 PS 5.1 语法面（`Join-Path` 位置参数 ≤ 2、无 PS 6/7 专有写法）、校验脚本纯 ASCII + CRLF、复核 README 全部 `#L` 锚点的标签**与内容**一致且不越界，并断言**跨文件契约**：manifest schemaVersion、包名、Node 窗口、默认端口、bundle 携带清单、`.cmd` 调用关系、平台预热参数、`installScriptPackages`/`nativePackages` 的存在性。退出码 0 才允许打包。

### 6.5 安装侧新增校验（已实现）

- 复制/离线安装后比对 `appFileCount`/`appBytes`（app 模式）与 manifest 的 `nativePackages` 是否在位；
  缺失即中止（平台错包或介质损坏）。
- npmcache 模式解析 npm 输出的"未放行脚本"清单并**自动补跑一次全量 `--allow-scripts`**，仍被跳过则中止。
- 首次安装写入 `update.checkOnStart=false`。

---

## 7. 失败模式与处置矩阵

| 症状 / 官方信号 | 含义 | 处置 |
| --- | --- | --- |
| `global-install-foreign-destination` / 无主 skipped | prefix 归属不匹配 | 用 `NPM_CONFIG_PREFIX=<InstallRoot>\app` 重试（`[实测]` 已验证可解） |
| `ENOTCACHED` / 依赖解析失败 | 传递依赖不在随包 cache 里 | 重建升级包（用目标版本预热 cache）；确认未改 registry（改 registry 会让缓存键失配 —— `[实测]` 踩过） |
| 停在 recovery pending | 9.5 旧驱动未完成交接 | `openclaw update repair --yes --json` |
| Windows 重命名失败（EPERM/EBUSY/EACCES） | 有进程占用文件 | updater 已重试 ~57.75s；仍失败则先 `gateway stop --force` 再重试 |
| 启动退出码 78 / `newer schema version`（本次升级后必然出现） | 磁盘数据库 schema 19 比旧构建支持的 17 新 | 降级解决不了；唯一路径是 `openclaw backup restore` 升级前归档 |
| 升级后想回退到 9.5 | 已跨 schema 迁移（§2.8） | 换回旧整树无效（旧包会拒绝启动）；只能恢复归档 |
| `node-runtime-preflight` | 目标版本跑不了当前 Node | 保持在 engines 窗口内（9.9 与 9.5 相同），避免触发私有 Node 下载 |
| 服务指向旧路径 | Windows 上 updater 不重绑 | `openclaw gateway install --force` |
| 构建时报"resolved packages for the wrong platform" | 平台包扫描发现非 win32-x64 的包（构建机平台误解析） | 用 `-Mode app` 在 Windows x64 上重建，或 `-Mode npmcache`（带 `--os/--cpu` 钉住） |
| 安装后报 "Missing win32-x64 package(s)" | 目标树缺 manifest 记录的原生包 | 介质损坏或包平台错；换包重来，不要继续用这棵树 |
| 安装时 "npm still reports install scripts it did not run" | 依赖的安装脚本被拒（npm 12 默认、或清单不全） | 用 Windows x64 上构建的 **app 模式**包（脚本在构建时就跑完） |

---

## 8. 待验证与未决

**必须真机确认的三件事**（决定主路径能否落地）：

1. **owner 判定**：设 `NPM_CONFIG_PREFIX=C:\OpenClaw\app` 后 `openclaw update --dry-run --tag <tgz>` 是否通过。macOS 端到端无法复现（沙箱禁用 `ps`，darwin 的 handoff 身份校验必失败；Windows 走独立的原生实现，不受此影响），只能真机验。
2. **依赖真走缓存**：气隙机上 `npm_config_offline=true` + 随包 cache 能否把 ~63 个传递依赖装齐。
3. **原生依赖**：目标机 npm 若为 12（默认拒绝依赖脚本），koffi / tree-sitter-bash / esbuild 的安装脚本是否被跳过 —— 这也是保留整树救援通道的价值所在。

> 目标机在公司在、**拿不回任何输出**，所以这三件事不靠"汇报-定稿"推进：诊断结论写在目标机本地
> `RECON.txt` 存档，放行判定由升级脚本内置的 `-DryRun` 闸门给出（见 `UPGRADE-BRIEF.md`）。

**未决 / 风险**：

- ~~9.5 的 `schemaVersions` 未知~~ → **已解决**：9.5 = `state 17 / agent 21`，9.9 = `state 19 / agent 24`，本次升级**确认跨 schema 迁移**，回滚只能靠升级前备份（§2.8 有实测证据）。`database preflight` 仍建议做，但已不再是"未知项判定"，而是留证。
- 升级期间磁盘峰值：官方是"stage 到临时 prefix 再 swap" `[文档]` `how-updates-run.md:1088-1096`，加上救援整树，峰值可能达 ~1.5GB；目标机余量需登记。
- `openclaw update` 是否尊重 `npm_config_*` 环境变量属 `[工程补充]` 推断（子进程继承环境），需真机验证。
- 9.6–9.8 的变更集在包内**无 CHANGELOG 记录**（9.9 的 CHANGELOG 只有 `## 2026.9.9` 一节），跳版本升级的中间变更不可查。
- 9.9 的 CHANGELOG 明确 "No intentional capability changes"，未声明破坏性/配置/引擎变化 `[文档]` `package/CHANGELOG.md:15`。

---

## 9. 附录：如何复现本文的官方出处

```bash
# 下载包（构建侧联网机器或任意可访问 npm 的机器）
npm pack openclaw@2026.9.9            # -> openclaw-2026.9.9.tgz

# 提取文档与 CHANGELOG
tar xzf openclaw-2026.9.9.tgz package/docs package/CHANGELOG.md package/package.json
# 本文引用形如 docs/cli/update.md:202，即 openclaw-2026.9.9 包内 package/docs/cli/update.md 第 202 行
```

关键入口文件：`docs/cli/update.md`、`docs/cli/update/how-updates-run.md`、`docs/cli/update/status-and-history.md`、`docs/cli/update/repair-and-recovery.md`、`docs/install/updating/update-methods.md`、`docs/install/updating/rollback-and-recovery.md`、`docs/install/updating/automatic-updates.md`、`docs/gateway/doctor/config-migrations.md`、`docs/cli/backup.md`、`docs/cli/gateway/service.md`、`docs/platforms/windows.md`、`docs/install/node-compatibility.md`。
